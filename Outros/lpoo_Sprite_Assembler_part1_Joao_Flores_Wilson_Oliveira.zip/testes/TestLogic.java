package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestLogic { //test the loading and reposition of the images

	@Test
	public void checkFiles() { //verifies if the save folder contains the expected files
		fail("Not yet implemented");
	}

}
