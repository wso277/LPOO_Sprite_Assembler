package test;

public class TestGui { //checks of gui actions present expected result

}
