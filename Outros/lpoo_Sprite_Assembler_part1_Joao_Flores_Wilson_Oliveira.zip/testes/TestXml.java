package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestXml {	//check if the writing and loading of the xml file is done correctly

	@Test
	public void checkTags() { //check for tags in the xml file
		fail("Not yet implemented");
		
	}

}
